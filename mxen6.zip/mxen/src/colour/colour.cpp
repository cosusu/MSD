// This C++ code can be used to set the background colour

#include <ros/ros.h>

int main(int argc, char ∗∗ argv)
{
    int r, g, b;

    ros::int(argc, argv, " set_bg_color ");
    ros::NodeHandle nh;

    // wait until a clear service is available.
    ros::service::waitForService("clear");

    //Set bg colour
    ros::param::set("turtlesim/background_r", 210);
    ros::param::set("turtlesim/background_g", 155);
    ros::param::set("turtlesim/background_b", 200);

    // //Get bg colour
    // r = ros::param::get("turtlesim/background_r");
    // g = ros::param::get("turtlesim/background_g");
    // b = ros::param::get("turtlesim/background_b");

    // ros::ServiceClient clearClient = nh.serviceClient<std_srvs::Empty>("/clear");
    // std_srvs::Empty srv;
    // clearClient.call(srv);
}