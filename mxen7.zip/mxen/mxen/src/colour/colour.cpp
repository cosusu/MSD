// This C++ code can be used to set the /turtlesim/background colour

#include <ros/ros.h>
#include <std_srvs/Empty.h>

int main(int argc, char ** argv)
{
    ros::init(argc, argv, "setBgColor");
    ros::NodeHandle nh;

    // wait until a clear service is available.
    ros::service::waitForService("clear");

    //Get current bg colour
    int r, g, b;
    ros::param::get("/turtlesim1/background_r", r);
    ros::param::get("/turtlesim1/background_g", g);
    ros::param::get("/turtlesim1/background_b", b);

    std::cout << "red: " << r << '\n';
    std::cout << "grn: " << g << '\n';
    std::cout << "blu: " << b << '\n';
    std::cout << '\n';

    //Set bg colour to pink
    ros::param::set("/turtlesim1/background_r", 210);
    ros::param::set("/turtlesim1/background_g", 155);
    ros::param::set("/turtlesim1/background_b", 200);

    ros::ServiceClient clearClient = nh.serviceClient<std_srvs::Empty>("/clear");
    std_srvs::Empty srv;
    clearClient.call(srv);
}