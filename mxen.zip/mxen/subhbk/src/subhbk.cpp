// This is a sample file named as subhbk.cpp.

#include <ros/ros.h>
#include <turtlesim/Pose.h>	//For pose
#include <iomanip>		//For std::setprecision and std::fixed
#include <geometry_msgs/Twist.h> //To handle the geometry_msgs::Twist
#include <stdlib.h>		// To handle rand() and RAND_MAX	

// Acall back function to execute eact new arriving message

void poseMessageReceived(const turtlesim:: Pose& msg) {
        ROS_INFO_STREAM(std::setprecision(2) <<std::fixed 
        << "position = (" <<msg.x << "," <<msg.y<<")"
	<< "direction =(" <<msg.theta <<")");
}


int main(int argc, char **argv){
        ros::init(argc, argv, "Subscribe_to_pose");
        ros::NodeHandle nh;

// The subscriber object is now declared

ros::Subscriber sub = nh.subscribe ("turtle1/pose", 1000, &poseMessageReceived);

	// Let's create a subscriber object
	ros::spin();
}
