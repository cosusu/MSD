// This is a sample file named as pubhbk.cpp.

#include <ros/ros.h>
#include <geometry_msgs/Twist.h> //To handle the geometry_msgs::Twist
#include <stdlib.h>		// To handle rand() and RAND_MAX	

//#include <sstream>
//#include <turtlesim/Pose.h>
//#include <iomanip>

//void poseMessageReceived(const turtlesim:: Pose& msg) {
//        ROS_INFO_STREAM(std::setprecision(2) <<std::fixed
//        << "position = (" <<msg.x << "," <<msg.y<<")"
//   	<<"direction = (" <<msg.theta <<")");
//}
int main(int argc, char **argv){
        ROS_INFO_STREAM("Hello MXEN4001, I am HBK! Helping, Brave and Kind");

        ros::init(argc, argv, "publish_velocity");
        ros::NodeHandle nh;
	// Let's create a publisher object
	ros::Publisher pub = nh.advertise<geometry_msgs::Twist>("turtle1/cmd_vel",1000);
	//Now we seed the random number generator

	srand(time(0));
	//Let's let this loop @2Hz as long as the node is running
	ros::Rate rate(2);

	while(ros::ok()) {
//	ros::spin();	
	geometry_msgs::Twist msg;
	msg.linear.x = double(rand())/double(RAND_MAX);
        msg.angular.z = 2*double(rand())/double(RAND_MAX) - 1;
	

	//The above two lines create and fill in messages. The other
	//fields default to a volue = 0.


	//This statement will publish the message
	pub.publish(msg);
	
	//This will send a message to ros
	ROS_INFO_STREAM("Random Velocity commands:"
	<<" linear="<<msg.linear.x
        <<" angular="<<msg.angular.z);
	ros::spinOnce();
	//This will cause the system to wait for the next iteration
//	ros::Rate rate(2);
//	ros::spin();    
	rate.sleep();
	}
// return ();
}
