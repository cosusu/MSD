// This is a sample file named as mxen.cpp.

#include <ros/ros.h>
int main(int argc, char **argv){
        ros::init(argc, argv, "Hello_MXEN4001");
        ros::NodeHandle nh;
        ROS_INFO_STREAM("Hello MXEN4001, I am HBK! Helping, Brave and Kind");
}
