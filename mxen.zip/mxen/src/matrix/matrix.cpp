// requests and saves nine elements for rotation matrix

#include <ros/ros.h>
#include <std_srvs/Empty.h>
#include <cmath>

int main(int argc, char ** argv)
{
    ros::init(argc, argv, "rqst_elements" ); //creates rqst elements node
    ros::NodeHandle nh;
    
    // wait until a clear service is available.
    // ros::service::waitForService("clear");

    // creates array for rotation matrix
    // float matrix[3][3] = {{0.1, 0.2, 0.3}, {0.4, 0.5, 0.6}, {0.7, 0.8, 0.9}}; // N = 1.5
    // float matrix[3][3] = {{-0.5, 0.2, 0.3}, {0.4, -0.5, 0.6}, {0.7, 0.8, 0}}; // N = -1
    float matrix[3][3] = {{1, 0.2, 0.3}, {0.4, 1, 0.6}, {0.7, 0.8, 1}}; // N = 3
    char res;
    std::cout << "Use default matrix? (y/n)\n";
    std::cin >> res;

    if(res == 'n')
    {
        // request elements for rotation matrix from user
        for(int ii=0; ii<3; ii++)
        {
            switch(ii)
            {
                case 0:
                    std::cout << "enter n-matrix rotation values\n";
                    break;
                case 1:
                    std::cout << "enter o-matrix rotation values\n";
                    break;
                case 2:
                    std::cout << "enter a-matrix rotation values\n";
                    break;
            }

            for(int jj=0; jj<3; jj++)
            {
                switch(jj)
                {
                    case 0:
                        std::cout << "row x: ";
                        break;
                    case 1:
                        std::cout << "row y: ";
                        break;
                    case 2:
                        std::cout << "row z: ";
                        break;
                }
                std::cin >> matrix[jj][ii];
            }
        }
    }

    std::cout << "\nEntered Matrix: \n";
    for(int ii=0; ii<3; ii++)
    {
        for(int jj=0; jj<3; jj++)
        {
            std::cout << matrix[ii][jj] << " ";
        }
        std::cout << '\n';
    }
    std::cout << '\n';

    //Equivalent Angle
    float N = matrix[0][0] + matrix[1][1] + matrix[2][2];
    float theta, mult;
    float vector_K[3][1];
    bool arb = false;

    if(N == 3) {
        std::cout << "N = 3 \n";
        theta = 0;
        arb = true;
    }
    else if(N==-1) {
        std::cout << "N = -1\n";
        theta = M_PI;
        vector_K[0][1] = sqrt((matrix[0][0]+1) / 2);
        vector_K[1][1] = matrix[1][0] / (2 * vector_K[0][1]);
        vector_K[2][1] = matrix[2][0] / (2 * vector_K[0][1]);
    }
    else if((N>-1)&&(N<3)) {
        std::cout << "N = " << N << '\n';
        theta = acos((N-1)/2);
        mult = 1 / (2 * sin(theta));
        vector_K[0][1] = (matrix[2][1]-matrix[1][2]) * mult;
        vector_K[1][1] = (matrix[0][2]-matrix[2][0]) * mult;
        vector_K[2][1] = (matrix[1][0]-matrix[0][1]) * mult;
    }
    else {
        std::cout << "Error, invalid matrix input. Diagonal sum must be between -1 and 3.\n";
    }

    std::cout << "Equivalent Angle = " << theta * 180 / M_PI << '\n';
    if(arb==false) {
        std::cout << "Rotation Matrix: \n";
        for(int kk=0; kk<3; kk++)
        {
            std::cout << vector_K[kk][1] << '\n';
        }
    }
    else {
        std::cout << "Rotation Matrix is arbiturary as angle is 0 \n";
    }

    ros::ServiceClient clearClient = nh.serviceClient<std_srvs::Empty>("/clear");
    std_srvs::Empty srv;
    clearClient.call(srv);
}
